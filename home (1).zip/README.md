# Machine Learning

## Python and Data Science

### A Linear Regression Model

Libraries Used:

- [Numpy](https://www.youtube.com/watch?v=lLRBYKwP8GQ&t=1073s)
- [Pandas](https://www.youtube.com/watch?v=zN2Hua6oII0&t=8s)
- [matplotlib](https://www.youtube.com/watch?v=nzKy9GY12yo)
- [scikit-learn intro](https://www.youtube.com/watch?v=rvVkVsG49uU)
- [scikit-learn tut](https://www.youtube.com/watch?v=M9Itm95JzL0)
- [pickle](https://www.youtube.com/watch?v=6Q56r_fVqgw)


References

